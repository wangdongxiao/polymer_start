sinon.js
========

SinonJS proxy repository for the BowerJS package manager

Install with: `bower install sinonjs`

For more information on SinonJS: https://github.com/cjohansen/Sinon.JS 
